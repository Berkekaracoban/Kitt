# KITT Asistan — APK Oluşturma

Bu proje GitHub Actions ile ücretsiz şekilde Android APK oluşturacak şekilde hazırlanmıştır.

## Telefonda APK oluşturma

1. Bu projenin dosyalarını GitHub deponun **ana dizinine** yükle.
2. GitHub'da deponu aç.
3. Üst menüden **Actions** sekmesine gir.
4. Soldan **KITT APK Build** iş akışını seç.
5. **Run workflow** düğmesine dokun ve tekrar **Run workflow** seç.
6. Derleme tamamlandığında yeşil tik görünür.
7. Tamamlanan çalışmayı aç.
8. Sayfanın altındaki **Artifacts** bölümünden **KITT-Asistan-APK** dosyasını indir.
9. İnen ZIP'i aç. İçindeki `app-debug.apk` dosyasını Android telefonuna kur.

> Not: Bu yöntem için bilgisayar, Android Studio veya Termux gerekmez. GitHub'ın sunucusu APK'yı derler.

## Yapılan uyumluluk düzeltmeleri

- Android `compileSdk` değeri kararlı **API 36** olarak ayarlandı.
- Eksik `debug.keystore` yüzünden oluşabilecek derleme hatası kaldırıldı; Android'in standart debug imzası kullanılır.
- Projede `gradlew` dosyası bulunmasa bile GitHub Actions doğrudan **Gradle 9.3.1** kurup derleme yapar.
- Java 21 ve Android SDK 36 iş akışında otomatik hazırlanır.

## Çıktı

APK yolu:

`app/build/outputs/apk/debug/app-debug.apk`
